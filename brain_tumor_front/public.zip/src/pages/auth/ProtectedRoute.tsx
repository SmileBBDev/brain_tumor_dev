import { Navigate } from 'react-router-dom';
import type { MenuId } from '@/types/menu';

// 권한 가드
interface Props{
    menu : MenuId;
    children : React.ReactNode;
}

export default function ProtectedRoute({menu, children}: Props){
    const menus: MenuId[] = JSON.parse(
        localStorage.getItem('menus') || '[]'
    );

    if(!menus.includes(menu)){
        return <Navigate to="/login" replace />;
    }
    return <>{children}</>;
}