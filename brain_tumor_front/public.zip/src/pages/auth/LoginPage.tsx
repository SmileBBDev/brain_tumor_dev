// 로그인 화면
import { useState } from 'react';
import { login, fetchMe, fetchMenu } from './auth.api';
import { useNavigate } from 'react-router-dom';

export default function LoginPage(){
    const [id, setId] = useState('');
    const [pw, setPw] = useState('');    
    const navigate = useNavigate();

    const handleLogin = async () => {
        // 임시 로그인 처리
        // 🔥 1. 임시 토큰
        localStorage.setItem('accessToken', 'mock-token');

        // 🔥 2. role 지정 (테스트하고 싶은 거로)
        //localStorage.setItem('role', 'DOCTOR');
        localStorage.setItem('role', 'NURSE');
        //localStorage.setItem('role', 'PATIENT');
        // localStorage.setItem('role', 'ADMIN');

        // 🔥 3. 해당 role에 맞는 메뉴
        localStorage.setItem(
            'menus',
            JSON.stringify([
                'DASHBOARD',
                'PATIENT_LIST',
                'IMAGE_VIEWER',
                'AI_SUMMARY',
            ])
        );

        navigate('/');



        // api 호출해서 로그인 처리 기능
        // try{
        //     const res = await login(id, pw);
        //     localStorage.setItem('accessToken', res.data.token);

        //     const me = await fetchMe();
        //     const menu = await fetchMenu();

        //     localStorage.setItem('role', me.data.role);
        //     localStorage.setItem('menu', JSON.stringify(menu.data.menus));

        //     navigate('/patients');
        // }catch(error){
        //     alert("로그인 실패")
        //     console.error(error);
        // }
        
    }

    return(
        <div>
             <input placeholder="ID" onChange={(e) => setId(e.target.value)} />
            <input type="password" placeholder="PW" onChange={(e) => setPw(e.target.value)} />
            <button onClick={handleLogin}>로그인</button>

        </div>
    )
}