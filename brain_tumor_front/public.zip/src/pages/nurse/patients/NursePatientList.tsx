// 간호사용 환자 목록
export default function NursePatientList() {
  return (
    <div>
      <h2>간호사용 환자 목록</h2>
      <p>기본 환자 정보만 표시</p>
    </div>
  );
}
