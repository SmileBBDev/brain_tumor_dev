// 비밀번호 변경 페이지
export default function PasswordChange(){
    return(
        <div>비밀번호 변경 페이지</div>
    )
};