// 환자 본인 진료 목록
export default function MyRecordList() {
  return (
    <div>
      <h2>내 진료 기록</h2>
      <p>본인 검사 / 영상 결과</p>
    </div>
  );
}
