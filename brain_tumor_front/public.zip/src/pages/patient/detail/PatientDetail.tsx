export default function PatientDetailPage(){
    return(
        <div>환자 상세 페이지</div>
    )
};