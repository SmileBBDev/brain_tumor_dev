// 의사용 환자 목록
export default function DoctorPatientList() {
  return (
    <div>
      <h2>의사용 환자 목록</h2>
      <p>전체 환자 조회 + 진단/AI 기능</p>
    </div>
  );
}
