export default function DashboardPage(){
    return(
        <div>대시보드 페이지</div>
    )
};