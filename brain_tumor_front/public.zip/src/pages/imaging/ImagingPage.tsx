export default function ImagingPage() {
    return (
        <div>검사 이미지, 영상 조회</div>
    );
}