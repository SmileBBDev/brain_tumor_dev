export default function AISummaryPage(){
    return(
        <div>AI 요약 페이지</div>
    )
}